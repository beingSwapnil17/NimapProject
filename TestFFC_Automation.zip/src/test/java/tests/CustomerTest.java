package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class CustomerTest {
    WebDriver driver;

    @DataProvider(name = "customerData")
    public Object[][] customerInfo() {
        return new Object[][] {
            {"Swapnil Enterprises", "swapnil123", "Maharashtra", "India"}
        };
    }

    @Test(dataProvider = "customerData")
    public void addCustomer(String name, String code, String state, String country) throws InterruptedException {
        driver.findElement(By.linkText("Customer")).click();
        driver.findElement(By.id("addCustomerBtn")).click();
        driver.findElement(By.id("customerName")).sendKeys(name);
        driver.findElement(By.id("customerCode")).sendKeys(code);
        driver.findElement(By.id("customerState")).sendKeys(state);
        driver.findElement(By.id("customerCountry")).sendKeys(country);
        driver.findElement(By.xpath("//button[text()='Save']")).click();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        WebElement toast = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("Toastify__toast-body")));
        Assert.assertTrue(toast.getText().contains("Customer Added Successfully"));
    }
}
