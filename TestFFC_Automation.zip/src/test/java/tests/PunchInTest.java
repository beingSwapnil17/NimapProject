package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class PunchInTest {
    WebDriver driver;

    @Test
    public void testPunchInToastMessage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        driver.findElement(By.id("punchInButton")).click();
        WebElement toast = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("Toastify__toast-body")));
        String toastMessage = toast.getText();
        Assert.assertTrue(toastMessage.contains("Punch In Successful"));
    }
}
